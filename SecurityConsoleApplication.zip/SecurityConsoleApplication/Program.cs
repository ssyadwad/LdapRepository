﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Security.Principal;

namespace SecurityConsoleApplication
{
    public class Program
    {

        private static void Main(string[] args)
        {

            var listGroups=new List<string>();
            try
            {
                listGroups = GetGroupsForCurrentLoggedinUser();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:---"+ex.Message);
            }

            foreach (var listGroup in listGroups)
            {
                Console.WriteLine(listGroup);
        
            }
            Console.ReadLine();
        }
         
        public static List<string> GetGroupsForCurrentLoggedinUser()
        {
            Console.WriteLine("Groups under the current logged in user :- ");
            Console.Write("\n");
            string username = WindowsIdentity.GetCurrent().Name; //Gets the current logged in user

            var currentDomainofLoggedinUser = Domain.GetCurrentDomain();
            var currentDomainController = currentDomainofLoggedinUser.FindDomainController(); //Gets the current Domain controller

            string strPath = "LDAP://" + currentDomainController.Name; //Gets the current domain controller name
            var currentLoggedinUser = username.Split('\\');
            var currentDirectoryEntry = new DirectoryEntry(strPath);
            var search = new DirectorySearcher(currentDirectoryEntry);
            search.Filter = "(&(objectClass=user)(objectCategory=person)(sAMAccountName=" + currentLoggedinUser[1] + "))";
            //search.Filter = "(&(objectClass=user)(objectCategory=person)(sAMAccountName=z003kkvy))";
            search.PropertiesToLoad.Add("sAMAccountName");
            search.PropertiesToLoad.Add("mail");
            search.PropertiesToLoad.Add("group");
            search.PropertiesToLoad.Add("displayname"); //first name
            //SearchResultCollection resultCol = search.FindAll();
            var userSearchResult = search.FindOne();
            var groupData = new List<string>();
            if (userSearchResult != null)
            {

                using (var groupsDirectoryEntry = new DirectoryEntry(userSearchResult.Path))
                {
                    if (groupsDirectoryEntry.Properties["memberOf"].Value != null)
                    {
                        groupData.AddRange(from object child in (IEnumerable) groupsDirectoryEntry.Properties["memberOf"].Value select child.ToString().Split('=')[1].Split(',')[0]);
                    }
                }
            }
            return groupData;
        } 
    }
}
